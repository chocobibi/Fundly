package member;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MemberDAO {

 private Connection conn;
 private PreparedStatement pstmt;
 private ResultSet rs;

 public MemberDAO() {
  try {
   String dbURL = "jdbc:mysql://localhost:3306/fundly";
   String dbID = "root";
   String dbPassword = "";
   Class.forName("com.mysql.jdbc.Driver");
   conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

  } catch (Exception e) {
   e.printStackTrace();
  }
 }

 public int login(String userID, String userPassword) {
  String SQL = "SELECT userPassword FROM member WHERE userID=?";
  try {
   pstmt = conn.prepareStatement(SQL);
   pstmt.setString(1, userID);
   rs = pstmt.executeQuery();
   if(rs.next()) {
	   if(rs.getString(1).equals(userPassword))
		   return 1;  // 로그인 성공
	   else
		   return 0;  // 비밀번호 불일치
   }
   return -1;  // 아이디가 없음
   
   }catch(Exception e) {
   e.printStackTrace();
   }
   return -2; // 데이터 베이스 오류

  }
 public int join(Member member) {
	 String SQL="INSERT INTO MEMBER(userID, userPassword,userName,userBirth, userGender, userEmail,userPhone) VALUES(?,?,?,?,?,?,?)";
	 try {
		 pstmt=conn.prepareStatement(SQL);
		 pstmt.setString(1,member.getUserID());
		 pstmt.setString(2,member.getUserPassword());
		 pstmt.setString(3,member.getUserName());
		 pstmt.setString(4,member.getUserBirth());
		 pstmt.setString(5,member.getUserGender());
		 pstmt.setString(6,member.getUserEmail());
		 pstmt.setString(7,member.getUserPhone());
		 return pstmt.executeUpdate();
		 
	 }catch(Exception e) {
		 e.printStackTrace();
	 }
	 return -1;//데이터베이스 오류
 }
 
 public String findID(String userName, String userEmail) {
	 String userID=null;
	 try {
	
		 String SQL="SELECT userID FROM member WHERE userName=? and userEmail=?";
		 pstmt=conn.prepareStatement(SQL);
		 pstmt.setString(1,userName);
		 pstmt.setString(2,userEmail);
		 rs=pstmt.executeQuery();
		
		if(rs.next()) 
			userID=rs.getString("userID");
		
	 }catch(Exception e) {
		e.printStackTrace();
		
	 }return userID;
    }
 	
 
public String findPW(String userID, String userName, String userEmail) {
	 String userPassword=null;
	 try {
	
		 String SQL="SELECT userPassword FROM member WHERE userID=? and userName=? and userEmail=?";
		 pstmt=conn.prepareStatement(SQL);
		 pstmt.setString(1,userID);
		 pstmt.setString(2,userName);
		 pstmt.setString(3,userEmail);
		 rs=pstmt.executeQuery();
		
		if(rs.next()) 
			userPassword=rs.getString("userPassword");
		
	 }catch(Exception e) {
		e.printStackTrace();
		
	 }return userPassword;
   }

public String update(String invest_propen) {
	 String SQL="INSERT INTO MEMBER(invest_propen) VALUES(?)";
	 try {
		 pstmt=conn.prepareStatement(SQL);
		 pstmt.setString(1,invest_propen);
		 return invest_propen;
		 
	 }catch(Exception e) {
		 e.printStackTrace();
	 }return invest_propen;
}

}	



 
 
