package my;

import java.util.Date;

public class Domestic_fund {
	   private int fund_number;
	   private String company_name;
	   private String fund_type;
	   private String set_amount;
	   private Date set_date;
	   private String prepayment_fee;
	   private String total_remuner;
	   private String fund_name;
	   private String risk;
	   private String m1_yield;
	   private String m3_yield;
	   private String y1_yield;
	   private String y3_yield;
	   private String repu_price;
	   private float m1_predict_price;
	   private float m3_predict_price;
	   private float m6_predict_price;
	   private float y1_predict_price;
	   private float current_price;
	   private String invest_propen;
	   
	   public Domestic_fund() {
	      
	   }

	   public Domestic_fund(int fund_number, String company_name, String fund_type, String set_amount, Date set_date,
	         String prepayment_fee, String total_remuner, String fund_name, String risk, String m1_yield,
	         String m3_yield, String y1_yield, String y3_yield, String repu_price, float m1_predict_price,
	         float m3_predict_price, float m6_predict_price, float y1_predict_price, float current_price,
	         String invest_propen) {
	      super();
	      this.fund_number = fund_number;
	      this.company_name = company_name;
	      this.fund_type = fund_type;
	      this.set_amount = set_amount;
	      this.set_date = set_date;
	      this.prepayment_fee = prepayment_fee;
	      this.total_remuner = total_remuner;
	      this.fund_name = fund_name;
	      this.risk = risk;
	      this.m1_yield = m1_yield;
	      this.m3_yield = m3_yield;
	      this.y1_yield = y1_yield;
	      this.y3_yield = y3_yield;
	      this.repu_price = repu_price;
	      this.m1_predict_price = m1_predict_price;
	      this.m3_predict_price = m3_predict_price;
	      this.m6_predict_price = m6_predict_price;
	      this.y1_predict_price = y1_predict_price;
	      this.current_price = current_price;
	      this.invest_propen = invest_propen;
	   }

	   public int getFund_number() {
	      return fund_number;
	   }

	   public void setFund_number(int fund_number) {
	      this.fund_number = fund_number;
	   }

	   public String getCompany_name() {
	      return company_name;
	   }

	   public void setCompany_name(String company_name) {
	      this.company_name = company_name;
	   }

	   public String getFund_type() {
	      return fund_type;
	   }

	   public void setFund_type(String fund_type) {
	      this.fund_type = fund_type;
	   }

	   public String getSet_amount() {
	      return set_amount;
	   }

	   public void setSet_amount(String set_amount) {
	      this.set_amount = set_amount;
	   }

	   public Date getSet_date() {
	      return set_date;
	   }

	   public void setSet_date(Date set_date) {
	      this.set_date = set_date;
	   }

	   public String getPrepayment_fee() {
	      return prepayment_fee;
	   }

	   public void setPrepayment_fee(String prepayment_fee) {
	      this.prepayment_fee = prepayment_fee;
	   }

	   public String getTotal_remuner() {
	      return total_remuner;
	   }

	   public void setTotal_remuner(String total_remuner) {
	      this.total_remuner = total_remuner;
	   }

	   public String getFund_name() {
	      return fund_name;
	   }

	   public void setFund_name(String fund_name) {
	      this.fund_name = fund_name;
	   }

	   public String getRisk() {
	      return risk;
	   }

	   public void setRisk(String risk) {
	      this.risk = risk;
	   }

	   public String getM1_yield() {
	      return m1_yield;
	   }

	   public void setM1_yield(String m1_yield) {
	      this.m1_yield = m1_yield;
	   }

	   public String getM3_yield() {
	      return m3_yield;
	   }

	   public void setM3_yield(String m3_yield) {
	      this.m3_yield = m3_yield;
	   }

	   public String getY1_yield() {
	      return y1_yield;
	   }

	   public void setY1_yield(String y1_yield) {
	      this.y1_yield = y1_yield;
	   }

	   public String getY3_yield() {
	      return y3_yield;
	   }

	   public void setY3_yield(String y3_yield) {
	      this.y3_yield = y3_yield;
	   }

	   public String getRepu_price() {
	      return repu_price;
	   }

	   public void setRepu_price(String repu_price) {
	      this.repu_price = repu_price;
	   }

	   public float getM1_predict_price() {
	      return m1_predict_price;
	   }

	   public void setM1_predict_price(float m1_predict_price) {
	      this.m1_predict_price = m1_predict_price;
	   }

	   public float getM3_predict_price() {
	      return m3_predict_price;
	   }

	   public void setM3_predict_price(float m3_predict_price) {
	      this.m3_predict_price = m3_predict_price;
	   }

	   public float getM6_predict_price() {
	      return m6_predict_price;
	   }

	   public void setM6_predict_price(float m6_predict_price) {
	      this.m6_predict_price = m6_predict_price;
	   }

	   public float getY1_predict_price() {
	      return y1_predict_price;
	   }

	   public void setY1_predict_price(float y1_predict_price) {
	      this.y1_predict_price = y1_predict_price;
	   }

	   public float getCurrent_price() {
	      return current_price;
	   }

	   public void setCurrent_price(float current_price) {
	      this.current_price = current_price;
	   }

	   public String getInvest_propen() {
	      return invest_propen;
	   }

	   public void setInvest_propen(String invest_propen) {
	      this.invest_propen = invest_propen;
	   }

	}