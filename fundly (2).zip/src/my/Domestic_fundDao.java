package my;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import my.Domestic_fund;
import util.JdbcUtil;

public class Domestic_fundDao {
	   
	   public List<Domestic_fund> selectList(Connection conn) 
	         throws SQLException {
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      List<Domestic_fund> domestic_fundList = null;
	      try {
	         pstmt = conn.prepareStatement
	               ("select * from domestic_fund order by (m3_yield+0) desc");
	         
	         rs  = pstmt.executeQuery(); 
	         domestic_fundList = new ArrayList<Domestic_fund>();
	         while (rs.next()){
	            Domestic_fund domestic_fund = new Domestic_fund();
	            domestic_fund.setFund_number(rs.getInt(1));      
	            domestic_fund.setCompany_name(rs.getString(2));
	            domestic_fund.setFund_type(rs.getString(3));
	            domestic_fund.setSet_amount(rs.getString(4));
	            domestic_fund.setSet_date(rs.getDate(5));
	            domestic_fund.setPrepayment_fee(rs.getString(6));
	            domestic_fund.setTotal_remuner(rs.getString(7));
	            domestic_fund.setFund_name(rs.getString(8));
	            domestic_fund.setRisk(rs.getString(9));
	            domestic_fund.setM1_yield(rs.getString(10));
	            domestic_fund.setM3_yield(rs.getString(11));
	            domestic_fund.setY1_yield(rs.getString(12));
	            domestic_fund.setY3_yield(rs.getString(13));
	            domestic_fund.setRepu_price(rs.getString(14));
	            domestic_fund.setM1_predict_price(rs.getFloat(15));
	            domestic_fund.setM3_predict_price(rs.getFloat(16));
	            domestic_fund.setM6_predict_price(rs.getFloat(17));
	            domestic_fund.setY1_predict_price(rs.getFloat(18));
	            domestic_fund.setCurrent_price(rs.getFloat(19));
	            domestic_fund.setInvest_propen(rs.getString(20));
	            domestic_fundList.add(domestic_fund);
	         }
	      } finally {
	         JdbcUtil.close(conn);
	         JdbcUtil.close(rs);
	         JdbcUtil.close(pstmt);
	      }
	      return domestic_fundList;
	   }
	   public List<Domestic_fund> selectList_m1(Connection conn) 
	            throws SQLException {
	         PreparedStatement pstmt = null;
	         ResultSet rs = null;
	         List<Domestic_fund> domestic_fundList1 = null;
	         try {
	            pstmt = conn.prepareStatement
	                  ("select * from domestic_fund order by (m1_yield+0) desc");
	            
	            rs  = pstmt.executeQuery(); 
	            domestic_fundList1 = new ArrayList<Domestic_fund>();
	            while (rs.next()){
	               Domestic_fund domestic_fund = new Domestic_fund();
	               domestic_fund.setFund_number(rs.getInt(1));      
	               domestic_fund.setCompany_name(rs.getString(2));
	               domestic_fund.setFund_type(rs.getString(3));
	               domestic_fund.setSet_amount(rs.getString(4));
	               domestic_fund.setSet_date(rs.getDate(5));
	               domestic_fund.setPrepayment_fee(rs.getString(6));
	               domestic_fund.setTotal_remuner(rs.getString(7));
	               domestic_fund.setFund_name(rs.getString(8));
	               domestic_fund.setRisk(rs.getString(9));
	               domestic_fund.setM1_yield(rs.getString(10));
	               domestic_fund.setM3_yield(rs.getString(11));
	               domestic_fund.setY1_yield(rs.getString(12));
	               domestic_fund.setY3_yield(rs.getString(13));
	               domestic_fund.setRepu_price(rs.getString(14));
	               domestic_fund.setM1_predict_price(rs.getFloat(15));
	               domestic_fund.setM3_predict_price(rs.getFloat(16));
	               domestic_fund.setM6_predict_price(rs.getFloat(17));
	               domestic_fund.setY1_predict_price(rs.getFloat(18));
	               domestic_fund.setCurrent_price(rs.getFloat(19));
	               domestic_fund.setInvest_propen(rs.getString(20));
	               domestic_fundList1.add(domestic_fund);
	            }
	         } finally {
	            JdbcUtil.close(conn);
	            JdbcUtil.close(rs);
	            JdbcUtil.close(pstmt);
	         }
	         return domestic_fundList1;
	      }
	   
	   public List<Domestic_fund> selectList_y1(Connection conn) 
	            throws SQLException {
	         PreparedStatement pstmt = null;
	         ResultSet rs = null;
	         List<Domestic_fund> domestic_fundList2 = null;
	         try {
	            pstmt = conn.prepareStatement
	                  ("select * from domestic_fund order by (y1_yield+0) desc");
	            
	            rs  = pstmt.executeQuery(); 
	            domestic_fundList2 = new ArrayList<Domestic_fund>();
	            while (rs.next()){
	               Domestic_fund domestic_fund = new Domestic_fund();
	               domestic_fund.setFund_number(rs.getInt(1));      
	               domestic_fund.setCompany_name(rs.getString(2));
	               domestic_fund.setFund_type(rs.getString(3));
	               domestic_fund.setSet_amount(rs.getString(4));
	               domestic_fund.setSet_date(rs.getDate(5));
	               domestic_fund.setPrepayment_fee(rs.getString(6));
	               domestic_fund.setTotal_remuner(rs.getString(7));
	               domestic_fund.setFund_name(rs.getString(8));
	               domestic_fund.setRisk(rs.getString(9));
	               domestic_fund.setM1_yield(rs.getString(10));
	               domestic_fund.setM3_yield(rs.getString(11));
	               domestic_fund.setY1_yield(rs.getString(12));
	               domestic_fund.setY3_yield(rs.getString(13));
	               domestic_fund.setRepu_price(rs.getString(14));
	               domestic_fund.setM1_predict_price(rs.getFloat(15));
	               domestic_fund.setM3_predict_price(rs.getFloat(16));
	               domestic_fund.setM6_predict_price(rs.getFloat(17));
	               domestic_fund.setY1_predict_price(rs.getFloat(18));
	               domestic_fund.setCurrent_price(rs.getFloat(19));
	               domestic_fund.setInvest_propen(rs.getString(20));
	               domestic_fundList2.add(domestic_fund);
	            }
	         } finally {
	            JdbcUtil.close(conn);
	            JdbcUtil.close(rs);
	            JdbcUtil.close(pstmt);
	         }
	         return domestic_fundList2;
	      }

	   
	   public Domestic_fund selectById(Connection conn, int fund_number) 
	         throws SQLException {
	      PreparedStatement pstmt=null; 
	      ResultSet rs = null;
	      Domestic_fund domestic_fund = null; 
	      try {
	         pstmt = conn.prepareStatement
	         ("select * from domestic_fund where fund_number = ?");
	         pstmt.setInt(1, fund_number);
	         rs = pstmt.executeQuery();
	         if (rs.next()){
	            domestic_fund = new Domestic_fund(); 
	            domestic_fund.setFund_number(rs.getInt(1));      
	            domestic_fund.setCompany_name(rs.getString(2));
	            domestic_fund.setFund_type(rs.getString(3));
	            domestic_fund.setSet_amount(rs.getString(4));
	            domestic_fund.setSet_date(rs.getDate(5));
	            domestic_fund.setPrepayment_fee(rs.getString(6));
	            domestic_fund.setTotal_remuner(rs.getString(7));
	            domestic_fund.setFund_name(rs.getString(8));
	            domestic_fund.setRisk(rs.getString(9));
	            domestic_fund.setM1_yield(rs.getString(10));
	            domestic_fund.setM3_yield(rs.getString(11));
	            domestic_fund.setY1_yield(rs.getString(12));
	            domestic_fund.setY3_yield(rs.getString(13));
	            domestic_fund.setRepu_price(rs.getString(14));
	            domestic_fund.setM1_predict_price(rs.getFloat(15));
	            domestic_fund.setM3_predict_price(rs.getFloat(16));
	            domestic_fund.setM6_predict_price(rs.getFloat(17));
	            domestic_fund.setY1_predict_price(rs.getFloat(18));
	            domestic_fund.setCurrent_price(rs.getFloat(19));
	            domestic_fund.setInvest_propen(rs.getString(20));
	         }
	      } catch (SQLException e){
	         e.printStackTrace();
	      } finally {
	         JdbcUtil.close(conn);
	         JdbcUtil.close(pstmt);
	         JdbcUtil.close(rs);
	      }
	      return domestic_fund;
	   }
	}